import React, { useState } from 'react';
import Layout from '../../common/Layout';
import Sidebar from '../Sidebar';
import { useAuth } from '../../../contexts/AuthContext';
import DashboardContent from './DashboardContent';
import HealthRecordsPage from './HealthRecordsPage';
import AppointmentsPage from './AppointmentsPage';
import AIChatbotPage from './AIChatbotPage';

const MigrantDashboard: React.FC = () => {
    const [activeView, setActiveView] = useState('Dashboard');
    const { user } = useAuth();

    const handleNavigate = (view: string) => {
        setActiveView(view);
    };

    const renderContent = () => {
        switch (activeView) {
            case 'Health Records':
                return <HealthRecordsPage />;
            case 'Appointments':
                return <AppointmentsPage />;
            case 'AI Chatbot':
                return <AIChatbotPage />;
            case 'Dashboard':
            default:
                return <DashboardContent onNavigate={handleNavigate} />;
        }
    };

    const getTitle = () => {
        if (activeView === 'Dashboard') {
            return `Welcome back, ${user?.name}!`;
        }
        return activeView;
    };

    const sidebar = <Sidebar activeView={activeView} onNavigate={setActiveView} />;

    return (
        <Layout title={getTitle()} sidebarContent={sidebar}>
            {renderContent()}
        </Layout>
    );
};

export default MigrantDashboard;
